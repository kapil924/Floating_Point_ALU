# Floating-Point-ALU
Verilog Gate level Implementation of floating point arithmetic as per IEEE 754

operation[1:0]

    00    =>   Addition
      
    01    =>   Substraction
      
    10    =>   Multiplication
      
    11    =>   Division
    
<br>RTL Schematic of the Main( ALU ) Module<br>
    
![Screenshot (96)](https://user-images.githubusercontent.com/67265356/118686821-ff349600-b821-11eb-92ec-e636a9389116.png)

<br>RTL Schematic inside the Main module <br>

![Screenshot (97)](https://user-images.githubusercontent.com/67265356/118688077-55ee9f80-b823-11eb-9ec6-8bc9fc83add5.png)
